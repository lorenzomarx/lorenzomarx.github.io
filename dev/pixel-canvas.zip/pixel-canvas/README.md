# 像素小畫家｜Pixel Canvas

A Pen created on CodePen.

Original URL: [https://codepen.io/garena-tw-eng/pen/bGxoRZR](https://codepen.io/garena-tw-eng/pen/bGxoRZR).

@chengn