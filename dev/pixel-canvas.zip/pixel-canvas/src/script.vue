<!-- Use preprocessors via the lang attribute! e.g. <template lang="pug"> -->
<template>
  <div id="app">
    <div class="title">
      <img src="https://i.ibb.co/cF21HLZ/my-pixel-2.png" />
      Pixel Canvas
      <img src="https://i.ibb.co/kg7qv7b/my-pixel-3.png" />
    </div>
    <div class="controls">
      <div v-if="!eraserMode">
        <label class="color-picker-label" for="colorPicker">Color picker</label>
        <input
          type="color"
          id="colorPicker"
          class="colorPicker"
          @input="onColorChange"
        />
        <div class="pixel" @click="undo"><p>Undo</p></div>
        <div class="pixel" @click="clear"><p>Clear</p></div>
        <!--         <div class="pixel" @click="showCSS = !showCSS">
          <p>{{ showCSS ? "Hide CSS" : "Show CSS" }}</p>
        </div> -->
        <div class="pixel" @click="download"><p>Download</p></div>
        <div class="pixel" @click="save"><p>Save</p></div>
      </div>
      <p class="erase-notice" v-else>
        Is erase mode, erased part cannot be undo!
      </p>
      <div class="pixel" @click="eraserMode = !eraserMode">
        <p>{{ !eraserMode ? "Eraser" : "Close Eraser" }}</p>
      </div>
    </div>
    <div
      class="canvas"
      @pointerover="pointerover"
      @pointermove="pointermove"
      @pointerout="pointerout"
      @pointerdown="isDragging = true"
      @pointerup="pointerup"
      @click="onClick"
    >
      <div
        id="my-pixel"
        class="draw-area"
        :style="{
          backgroundPosition: position.join(','),
          backgroundImage: bg.join(',')
        }"
      >
        <div
          class="marker"
          :style="{
            backgroundPosition: markerPosition,
            opacity: markerOpacity,
            '--bg': color
          }"
        ></div>
      </div>
    </div>
    <div class="images">
      <div
        v-for="(i, index) in savedImages"
        @click="paste(i.bg, i.position)"
        :key="`${i.url}-${index}`"
      >
        <img :src="i.url" />
        <button @click.stop="deleteImage(i)">X</button>
      </div>
    </div>
    <textArea v-if="showCSS">background-image: {{ bg }}</textArea>
    <textArea v-if="showCSS">
      background-position:
      {{ position }}
    </textArea>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, reactive } from "vue";
import * as htmlToImage from "https://esm.sh/html-to-image@1.11.11";
import fileSaver from "https://esm.sh/file-saver@2.0.5";

const width = 600;
const height = 450;
const columns = 30;
const rows = (30 * 450) / 600;

const markerPosition = ref("0% 0%");
const markerOpacity = ref(0);

const bg = ref([]);
const position = ref([]);
const color = ref("black");

const isDragging = ref(false);
const preventClick = ref(false);

const showCSS = ref(false);
const eraserMode = ref(false);

const onColorChange = (e) => {
  color.value = e.target.value;
};

const pointerover = () => {
  markerOpacity.value = 1;
};

const pointerout = () => {
  markerOpacity.value = 0;
  isDragging.value = false;
};

const pointerup = () => {
  isDragging.value = false;
  setTimeout(() => (preventClick.value = false), 300);
};
// paint
const paint = (x, y) => {
  bg.value = [`linear-gradient(${color.value}, ${color.value})`, ...bg.value];
  position.value = [`${x}% ${y}%`, ...position.value];
};

// draw position
const bisect = d3.bisector((d) => d);

const dx = (posX) => {
  const stepX = 1 / (columns - 1);
  const dataX = d3.range(0, 100, stepX);
  const indexX = bisect.center(dataX, posX / width);
  return (dataX[indexX] * 100).toFixed(2);
};

const dy = (posY) => {
  const stepY = 1 / (rows - 1);
  const dataY = d3.range(0, 1, stepY);
  const indexY = bisect.center(dataY, posY / height);
  return (dataY[indexY] * 100).toFixed(2);
};

const generatePos = (e) => {
  const [posX, posY] = d3.pointer(e);
  const x = dx(posX);
  const y = dy(posY);
  return { x, y };
};

const checkDraw = (newBg, newPosition) => {
  if (
    !isDragging.value ||
    !bg.value ||
    (position.value && position.value[0] === newPosition)
  )
    return false;
  return true;
};

const pointermove = (e) => {
  const { x, y } = generatePos(e);

  markerPosition.value = `${x}% ${y}%`;

  const newBg = `linear-gradient(${color.value}, ${color.value})`;
  const newPosition = `${x}% ${y}%`;

  if (isDragging.value) {
    preventClick.value = true;
  }

  if (eraserMode.value && isDragging.value) {
    const index = position.value.findIndex((p) => p === newPosition);
    if (index >= 0) {
      bg.value.splice(index, 1);
      position.value.splice(index, 1);
    }

    return;
  }

  if (!checkDraw(newBg, newPosition)) return;
  paint(x, y);
};

const onClick = (e) => {
  const { x, y } = generatePos(e);

  const newBg = `linear-gradient(${color.value}, ${color.value})`;
  const newPosition = `${x}% ${y}%`;

  if (eraserMode.value) {
    const index = position.value.findIndex((p) => p === newPosition);
    if (index >= 0) {
      bg.value.splice(index, 1);
      position.value.splice(index, 1);
    }

    return;
  }

  if (preventClick.value) return;

  paint(x, y);
};

watch(eraserMode, (v) => {
  if (v) color.value = "white";
  else color.value = "black";
});

// controls
const undo = () => {
  bg.value.shift();
  position.value.shift();
};

const clear = () => {
  bg.value = [];
  position.value = [];
};

const download = () => {
  if (bg.value.length < 1 || position.value.length < 1) {
    alert("Nothing to download!");
    return;
  }
  const node = document.getElementById("my-pixel");

  htmlToImage
    .toPng(node)
    .then(function (blob) {
      if (window.saveAs) {
        window.saveAs(blob, "my-pixel.png");
      } else {
        FileSaver.saveAs(blob, "my-pixel.png");
      }
    })
    .catch(function (error) {
      console.error("oops, something went wrong!", error);
    });
};

const paste = (b, p) => {
  clear();
  bg.value.push(...b);
  position.value.push(...p);
};
const savedImages = ref([]);

const save = () => {
  if (bg.value.length < 1 || position.value.length < 1) {
    alert("Nothing to save!");
    return;
  }
  const node = document.getElementById("my-pixel");

  htmlToImage
    .toPng(node)
    .then(function (dataUrl) {
      savedImages.value.push({
        url: dataUrl,
        bg: bg.value,
        position: position.value
      });
      localStorage.setItem("list", JSON.stringify(savedImages.value));
    })
    .catch(function (error) {
      console.error("oops, something went wrong!", error);
    });
};

const deleteImage = (i) => {
  const index = savedImages.value.findIndex(
    (image) => image.bg === i.bg && image.position === i.position
  );
  savedImages.value.splice(index, 1);
  localStorage.setItem("list", JSON.stringify(savedImages.value));
};

onMounted(() => {
  const initialList = JSON.parse(localStorage.getItem("list"));
  if (initialList?.length > 0) savedImages.value = initialList;
  document.addEventListener("keydown", function (event) {
    if (event.metaKey && event.key === "z") {
      undo();
    }
  });
});
</script>

<!-- Use preprocessors via the lang attribute! e.g. <style lang="scss"> -->
<style lang="scss">
body {
  background-color: gray;
  font-size: 20px;
}
img {
  pointer-events: none;
}
#app {
  font-family: "VT323", Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #2c3e50;
  width: 600px;
  height: 450px;
}

#colorPicker {
  position: absolute;
  left: 630px;
  margin-top: 10px;
}

.color-picker-label {
  position: absolute;
  left: 680px;
  margin-top: 10px;
}

.title {
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;

  font-size: 40px;
  color: #80d0ea;
  margin: 20px 0;
  > img {
    margin-bottom: -10px;
    height: 45px;
    width: 60px;
  }
}

label {
  color: white;
  margin-left: 10px;
}

.canvas {
  margin-top: 20px;
  margin-bottom: 30px;
  --cellSizeCol: 3.33333%;
  --cellSizeRow: 4.44635%;
  --colCount: 30;
  --rowCount: 40;
  --sizeX: var(--cellSizeCol, calc(100% / var(--colCount, 40)));
  --sizeY: var(--cellSizeRow, calc(100% / var(--rowCount, 30)));
  grid-column: 1;
  position: relative;
  background: linear-gradient(
      to right,
      transparent calc(100% - 1px),
      lightgrey 0
    ),
    linear-gradient(to bottom, transparent calc(100% - 1px), lightgrey 0), white;
  background-size: var(--sizeX) 100%, 100% var(--sizeY);
  outline: 0.3rem solid;

  .draw-area {
    position: relative;
    aspect-ratio: 4 / 3;
    background-repeat: no-repeat;
    background-size: var(--sizeX) var(--sizeY);
  }

  .marker {
    --bg: gray;
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-image: linear-gradient(
      to right,
      var(--bg, black),
      var(--bg, black)
    );
    aspect-ratio: 1;
    background-size: var(--sizeX) var(--sizeY);
    background-repeat: no-repeat;
    opacity: 0;
  }
}

.images {
  background-color: white;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  width: 630px;
  > div {
    position: relative;
    margin-right: 10px;
    margin-top: 10px;
    justify-content: flex-start;
    > img {
      width: 200px;
      height: 150px;
    }
    > button {
      font-family: "VT323";
      position: absolute;
      right: -10px;
      top: -5px;
    }
  }
}

textArea {
  margin-top: 30px;
  width: 600px;
  height: 300px;
}

.erase-notice {
  font-size: 25px;
  color: white;
  height: auto;
  margin: 30px 0 25px 0;
  font-family: "VT323";
}

.pixel {
  font-size: 25px;
  color: white;
  height: auto;
  margin: 10px;
  font-family: "VT323";

  position: relative;
  display: inline-block;
  vertical-align: top;
  text-transform: uppercase;

  cursor: pointer;

  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

.pixel:active {
  top: 2px;
}

.pixel {
  line-height: 0;

  image-rendering: optimizeSpeed;
  image-rendering: -moz-crisp-edges; /* Firefox */
  image-rendering: -o-crisp-edges; /* Opera */
  image-rendering: -webkit-optimize-contrast; /* Webkit (non-standard naming) */
  image-rendering: crisp-edges;
  -ms-interpolation-mode: nearest-neighbor; /* IE (non-standard property) */

  border-style: solid;
  border-width: 20px;
  -moz-border-image: url(https://i.imgur.com/sREM8Yn.png) 20 stretch;
  -webkit-border-image: url(https://i.imgur.com/sREM8Yn.png) 20 stretch;
  -o-border-image: url(https://i.imgur.com/sREM8Yn.png) 20 stretch;
  border-image: url(https://i.imgur.com/sREM8Yn.png) 20 stretch;
}

.pixel p {
  display: inline-block;
  vertical-align: top;
  position: relative;
  width: auto;
  text-align: center;
  margin: -20px -20px;
  line-height: 20px;
  padding: 10px 20px;

  background: #000000;
  background: linear-gradient(135deg, transparent 10px, #000000 0) top left,
    linear-gradient(225deg, transparent 10px, #000000 0) top right,
    linear-gradient(315deg, transparent 10px, #000000 0) bottom right,
    linear-gradient(45deg, transparent 10px, #000000 0) bottom left;
  background-size: 50% 50%;
  background-repeat: no-repeat;
  background-image: radial-gradient(
      circle at 0 0,
      rgba(204, 0, 0, 0) 14px,
      #000000 15px
    ),
    radial-gradient(circle at 100% 0, rgba(204, 0, 0, 0) 14px, #000000 15px),
    radial-gradient(circle at 100% 100%, rgba(204, 0, 0, 0) 14px, #000000 15px),
    radial-gradient(circle at 0 100%, rgba(204, 0, 0, 0) 14px, #000000 15px);
}
</style>
